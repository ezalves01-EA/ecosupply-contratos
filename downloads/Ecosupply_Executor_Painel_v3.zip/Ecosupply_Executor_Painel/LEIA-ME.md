# Ecosupply — reagendamento local em lote v2

## Uso
Requer Python 3.11+ e Chrome. Extraia em uma pasta própria, fora do painel. Windows: INICIAR_WINDOWS.bat. Linux: `sh INICIAR_LINUX.sh`.

1. Abra ids.txt e coloque os IDs desejados, um por linha. Alternativamente deixe vazio e cole a lista no terminal ao iniciar; uma linha vazia termina a entrada.
2. Informe nova data, motivo real e se o caminhão saiu. Esses valores serão os mesmos para TODOS os IDs. Turno: qualquerturno, único valor observado. Se dados variarem, faça lotes separados.
3. Confira os IDs exibidos e conferencia_lote.json. Duplicados da lista são retirados. Limite: 100 IDs por execução.
4. Faça login no Chrome aberto e confira os registros no SISGR. O programa não valida status ou data atual automaticamente. Não inclua realizados/efetivados neste fluxo de reagendamento pendente.
5. Volte ao terminal e digite a frase apresentada, por exemplo ALTERAR LOTE 10. Então ocorre uma chamada por ID, com três segundos entre elas.
6. Confira as novas datas no SISGR após terminar. O relatório registra solicitação aceita, não confirmação independente da data final.

## Histórico e interrupção
historico.sqlite registra a intenção ANTES de enviar cada ID. Uma tentativa para o mesmo ID e mesma data não é reenviada automaticamente, mesmo com motivo diferente. Timeout, redirect, resposta inesperada e erro interrompem o lote sem repetição. Na próxima execução, IDs já tentados são ignorados e os ainda não enviados continuam disponíveis. Preserve esse banco e use sempre a mesma pasta; ele não incorpora resultados da v1 automaticamente. Retire da lista os IDs já testados na v1 se a data desejada já foi aplicada.

Em falha ambígua, confira o cadastro antes de tentar qualquer repetição. Não apague o histórico para forçar reenvio. Após queda brusca pode restar lote_em_execucao.lock: só remova se tiver certeza de que o processo anterior terminou. Durante execução normal ele é retirado ao sair. Não abra duas cópias da ferramenta simultaneamente.

Relatórios resultados/lote_*.jsonl contêm ID, data, HTTP e resultado, sem cookies ou resposta bruta. O banco também guarda motivo e campo de saída para auditoria. Não há transmissão dessas informações para serviços externos além do SISGR.

## Sessão e campo de saída
Usa a rota observada POST /agendamentos/reagendar pela sessão do Chrome, sem token de API, exportar cookies ou reaproveitar credenciais expostas. Login/MFA são feitos por você. A rota foi validada por você para um ID e caminhaoSaiu=1. Com resposta aceita, o sistema ainda exige conferência da data no cadastro.

Se caminhão não saiu, caminhaoSaiu é omitido como checkbox desmarcado: esse cenário ainda não foi validado no SISGR. Comece com um ID nessa condição. A automação não tenta valores alternativos, nem resolve proteção CSRF por adivinhação. Se mudar a interface/proteção, interrompa e envie o diagnóstico sanitizado.

O teste individual anterior continua disponível via `python reagendar.py`, mas não compartilha o bloqueio de reenvio desta v2; prefira a versão em lote mesmo com um único ID. Não execute os dois ao mesmo tempo.

Validação do lote feita com respostas simuladas; nenhuma execução em lote real foi feita pelo assistente. O painel de logística permanece separado e inalterado.

## v3 — lote preparado no painel
No painel v1.12, abra Reagendamento em lote. Escolha o mês e use cidade, motorista e datas. Marque IDs, selecione todos dos filtros (até 100), ou cole IDs que pertençam aos pendentes filtrados. A seleção é mantida ao trocar filtros; confira o resumo completo, inclusive itens ocultos pelos filtros. Ao trocar o mês/base ela é limpa.

Preencha nova data, motivo e saída, confira e baixe o JSON. Use INICIAR_LOTE_DO_PAINEL.bat no Windows ou `sh INICIAR_LOTE_DO_PAINEL.sh` no Linux. Informe o caminho do JSON (arrastar ao terminal costuma preencher). O executor mostra IDs, datas de origem e nova data, abre Chrome para login e pede a confirmação antes de enviar. Não executa URLs ou código do arquivo.

Copie historico.sqlite da v2 para esta pasta ANTES de executar, preservando o histórico de tentativas. Não substitua pelo banco do painel. O lote do painel não usa ids.txt; os iniciadores antigos continuam aceitando lista manual.

Após concluir, confira as datas no SISGR. No painel, sincronize as quinzenas ou meses de origem e destino. Nenhuma data é atualizada no painel só porque a solicitação foi aceita. O painel não valida status atual ao vivo antes da exportação: ROTA é o status da última base salva. Confira os registros antes de confirmar no executor.
