"""Teste local: uma chamada por ID pela sessão do Chrome. Não usa token da API."""
import csv,datetime as dt,json,re,time
from pathlib import Path
from urllib.parse import urlsplit
ROOT=Path(__file__).resolve().parent
ORIGIN='https://ecosupply.sisgr.com'

def validate(vid,date,turn,reason,left):
    if not re.fullmatch(r'[1-9][0-9]*',vid):raise ValueError('ID inválido.')
    parsed=dt.datetime.strptime(date,'%d/%m/%Y').date()
    if parsed.strftime('%d/%m/%Y')!=date:raise ValueError('Use dd/mm/aaaa.')
    if turn!='qualquerturno':raise ValueError('Neste teste, somente turno qualquerturno foi confirmado.')
    if not reason.strip() or len(reason)>1000:raise ValueError('Informe motivo de até 1000 caracteres.')
    if left not in ('s','n'):raise ValueError('Responda s ou n para saída do veículo.')
    result={'agendamentoIds':vid,'novaData':date,'novoTurno':turn,'motivo':reason.strip()}
    if left=='s':result['caminhaoSaiu']='1'
    return result

def outcome(result,vid):
    if result.get('uncertain'):return 'INDETERMINADO — confira no SISGR antes de repetir'
    if result.get('redirected') or not 200<=result.get('http',0)<300:return 'NÃO CONFIRMADO — HTTP/redirect inesperado'
    data=result.get('data')
    if not isinstance(data,dict):return 'NÃO CONFIRMADO — resposta diferente da esperada'
    item=data.get('agendamentos',{}).get(vid,{}) if isinstance(data.get('agendamentos'),dict) else {}
    if data.get('erro') is False and item.get('erro') is False:return 'SOLICITAÇÃO ACEITA — confira a data no SISGR'
    return 'NÃO CONFIRMADO — resposta sem confirmação de sucesso por ID'

SCRIPT="""
const payload=arguments[0],done=arguments[arguments.length-1];
if(location.origin!=='https://ecosupply.sisgr.com'){done({uncertain:true});return;}
fetch('/agendamentos/reagendar',{method:'POST',credentials:'same-origin',redirect:'error',
 headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8','Accept':'application/json, text/javascript, */*; q=0.01','X-Requested-With':'XMLHttpRequest'},
 body:new URLSearchParams(payload).toString()})
.then(async r=>{let data=null;try{data=await r.json()}catch{};
 // Retain only expected success flags. Never export cookies, tokens, or raw HTML.
 const id=payload.agendamentoIds,entry=data?.agendamentos?.[id];
 done({http:r.status,redirected:r.redirected,data:data?{erro:data.erro,agendamentos:{[id]:{erro:entry?.erro}}}:null});})
.catch(()=>done({uncertain:true}));
"""

def main():
    print('ECOSUPPLY — TESTE LOCAL DE REAGENDAMENTO (1 ID)')
    print('Não repita um teste já aceito. Primeiro confira a data no cadastro.')
    try:
        vid=input('ID do agendamento a alterar: ').strip()
        date=input('Nova data (dd/mm/aaaa): ').strip()
        reason=input('Motivo real do reagendamento: ').strip()
        left=input('O veículo saiu para coleta? (s/n): ').strip().lower()
        payload=validate(vid,date,'qualquerturno',reason,left)
    except ValueError as e:raise SystemExit(str(e))
    print('\nCONFIRA:')
    print(json.dumps(payload,ensure_ascii=False,indent=2))
    if left=='n':print('Veículo não saiu: campo caminhaoSaiu será omitido, como checkbox desmarcado. Ainda não validado ao vivo.')
    print('Turno: qualquer turno. Esta ferramenta ainda não valida status nem data atual automaticamente.')
    from selenium import webdriver
    options=webdriver.ChromeOptions()
    driver=webdriver.Chrome(options=options)
    driver.set_script_timeout(90)
    try:
        driver.get(ORIGIN)
        input('\nFaça login no Chrome aberto, abra e confira o agendamento (ID, data e status). Depois volte aqui e pressione Enter. ')
        url=urlsplit(driver.current_url)
        if url.scheme!='https' or url.netloc!='ecosupply.sisgr.com':raise SystemExit('Navegador fora do domínio SISGR. Nada enviado.')
        confirm=input(f'Para solicitar a mudança de SOMENTE {vid} para {date}, digite ALTERAR {vid}: ').strip()
        if confirm!='ALTERAR '+vid:print('Cancelado. Nada enviado.');return
        # Save intent before dispatch: interruption can leave a request with unknown result.
        logs=ROOT/'resultados';logs.mkdir(exist_ok=True)
        log=logs/(dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'_'+vid+'.json')
        record={'enviadoEm':dt.datetime.now(dt.timezone.utc).isoformat(),'dados':payload,'resultado':'INDETERMINADO — envio pode ter ocorrido; confira no SISGR'}
        log.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
        try:result=driver.execute_async_script(SCRIPT,payload)
        except Exception:result={'uncertain':True}
        if not isinstance(result,dict):result={'uncertain':True}
        record.update(resultado=outcome(result,vid),http=result.get('http'))
        log.write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
        print('\n'+record['resultado']);print('Relatório:',log)
        input('Confira a nova data no próprio SISGR, atualizando a página. Enter para fechar o navegador. ')
    finally:driver.quit()

if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('\nInterrompido. Se já iniciou o envio, confira no SISGR antes de tentar novamente.')
