from lote import main
if __name__=='__main__':
    try:
        path=input('Caminho do lote JSON baixado do painel (pode arrastar o arquivo para o terminal): ').strip().strip('"').strip("'")
        main(path)
    except (ValueError,OSError) as e:print('Não foi possível iniciar:',e)
    except KeyboardInterrupt:print('Interrompido. Confira o SISGR antes de repetir um envio.')
