import tempfile,unittest
from pathlib import Path
from unittest.mock import Mock
from lote import parse_ids,open_ledger,claim,execute_plan
from reagendar import validate
class BatchTests(unittest.TestCase):
 def plan(self):return [validate(str(i),'12/11/2026','qualquerturno','Ajuste autorizado','s') for i in [1,2,3]]
 def accepted(self,id):return {'http':200,'data':{'erro':False,'agendamentos':{str(id):{'erro':False}}}}
 def test_parse_deduplicates(self):self.assertEqual(parse_ids('# comentário\n1,2;1\n3'),(['1','2','3'],1))
 def test_bad_id_rejected(self):
  with self.assertRaises(ValueError):parse_ids('1\n2x')
 def test_maximum(self):
  with self.assertRaises(ValueError):parse_ids(' '.join(map(str,range(1,102))))
 def test_sequence_and_no_resend(self):
  with tempfile.TemporaryDirectory() as tmp:
   db=open_ledger(Path(tmp)/'db');driver=Mock();driver.execute_async_script.side_effect=[self.accepted(i) for i in [1,2,3]];delay=Mock()
   with (Path(tmp)/'out').open('w') as f:
    records=execute_plan(driver,self.plan(),db,f,delay)
    again=execute_plan(driver,self.plan(),db,f,delay)
   self.assertEqual(len(records),3);self.assertEqual(again,[]);self.assertEqual(driver.execute_async_script.call_count,3);self.assertEqual(delay.call_count,2)
   db.close()
 def test_uncertain_stops_without_claiming_remaining(self):
  with tempfile.TemporaryDirectory() as tmp:
   db=open_ledger(Path(tmp)/'db');driver=Mock();driver.execute_async_script.side_effect=TimeoutError()
   with (Path(tmp)/'out').open('w') as f:records=execute_plan(driver,self.plan(),db,f,lambda _:None)
   self.assertEqual(len(records),1);self.assertEqual(driver.execute_async_script.call_count,1)
   self.assertEqual(db.execute('SELECT id,status FROM attempts').fetchall(),[('1','CONFERIR')]);db.close()
 def test_crash_intent_is_durable(self):
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'db';db=open_ledger(path);self.assertTrue(claim(db,self.plan()[0]));db.close()
   db=open_ledger(path);self.assertFalse(claim(db,self.plan()[0]));self.assertEqual(db.execute('SELECT status FROM attempts').fetchone()[0],'INDETERMINADO');db.close()
 def test_per_id_failure_stops(self):
  with tempfile.TemporaryDirectory() as tmp:
   db=open_ledger(Path(tmp)/'db');driver=Mock();driver.execute_async_script.return_value={'http':200,'data':{'erro':False,'agendamentos':{'1':{'erro':True}}}}
   with (Path(tmp)/'out').open('w') as f:records=execute_plan(driver,self.plan(),db,f,lambda _:None)
   self.assertEqual(len(records),1);self.assertEqual(driver.execute_async_script.call_count,1);db.close()

class PanelPlanTests(unittest.TestCase):
 def source(self):return {'format':'ecosupply-reschedule-plan','version':1,'sourceMonth':'2026-11','newDate':'24/11/2026','turn':'qualquerturno','reason':'Revisão','left':'s','items':[{'id':'123','sourceDate':'2026-11-02','status':'ROTA'}]}
 def test_valid_plan_matches_observed_payload(self):
  from lote import load_panel_plan
  import json
  with tempfile.TemporaryDirectory() as tmp:
   path=Path(tmp)/'plan.json';path.write_text(json.dumps(self.source()));source,plan=load_panel_plan(path)
   self.assertEqual(plan[0]['agendamentoIds'],'123');self.assertEqual(plan[0]['novaData'],'24/11/2026');self.assertEqual(plan[0]['caminhaoSaiu'],'1')
 def test_nonpending_and_duplicate_and_source_mismatch_rejected(self):
  from lote import load_panel_plan
  import json
  for mode in ['done','duplicate','month']:
   data=self.source()
   if mode=='done':data['items'][0]['status']='EFETIVADO'
   if mode=='duplicate':data['items']*=2
   if mode=='month':data['items'][0]['sourceDate']='2026-10-02'
   with tempfile.TemporaryDirectory() as tmp:
    path=Path(tmp)/'plan.json';path.write_text(json.dumps(data))
    with self.assertRaises(ValueError):load_panel_plan(path)
