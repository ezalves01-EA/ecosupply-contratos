import unittest
from reagendar import validate,outcome
class Tests(unittest.TestCase):
 def test_payload_confirmed_shape(self):
  p=validate('135159','09/11/2026','qualquerturno','Teste autorizado','s')
  self.assertEqual(p['caminhaoSaiu'],'1');self.assertEqual(p['agendamentoIds'],'135159')
 def test_unchecked_not_reported_as_left(self):self.assertNotIn('caminhaoSaiu',validate('1','09/11/2026','qualquerturno','Motivo','n'))
 def test_invalid_date_or_id(self):
  for vid,date in [('1','31/02/2026'),('1,2','09/11/2026')]:
   with self.assertRaises(ValueError):validate(vid,date,'qualquerturno','Motivo','n')
 def test_each_id_must_succeed(self):
  self.assertIn('ACEITA',outcome({'http':200,'data':{'erro':False,'agendamentos':{'1':{'erro':False}}}},'1'))
  self.assertIn('NÃO CONFIRMADO',outcome({'http':200,'data':{'erro':False,'agendamentos':{}}},'1'))
 def test_timeout_not_success(self):self.assertIn('INDETERMINADO',outcome({'uncertain':True},'1'))
 def test_html_or_login_not_success(self):
  self.assertIn('NÃO CONFIRMADO',outcome({'http':200,'data':None},'1'))
  self.assertIn('NÃO CONFIRMADO',outcome({'http':200,'redirected':True},'1'))
if __name__=='__main__':unittest.main()
