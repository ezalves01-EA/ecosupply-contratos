"""Lote sequencial por sessão do navegador. Sem repetição automática."""
import datetime as dt,json,os,re,sqlite3,time
from pathlib import Path
from urllib.parse import urlsplit
from reagendar import validate,outcome,SCRIPT,ORIGIN,ROOT

def parse_ids(text):
    tokens=[]
    for line in text.splitlines():
        if line.strip().startswith('#'):continue
        tokens.extend(re.split(r'[\s,;]+',line.strip()))
    tokens=[x for x in tokens if x]
    if any(not re.fullmatch(r'[1-9][0-9]*',x) for x in tokens):raise ValueError('Use somente IDs numéricos separados por linha, espaço, vírgula ou ponto e vírgula.')
    ids=list(dict.fromkeys(tokens))
    if not ids:raise ValueError('Lista vazia.')
    if len(ids)>100:raise ValueError('Limite de 100 IDs por execução. Divida a lista.')
    return ids,len(tokens)-len(ids)

def open_ledger(path):
    db=sqlite3.connect(path)
    db.execute('CREATE TABLE IF NOT EXISTS attempts(id TEXT,date TEXT,status TEXT,payload TEXT,at TEXT,http INTEGER,PRIMARY KEY(id,date))');db.commit()
    return db

def claim(db,p):
    cur=db.execute('INSERT OR IGNORE INTO attempts VALUES(?,?,?,?,?,NULL)',(p['agendamentoIds'],p['novaData'],'INDETERMINADO',json.dumps(p,ensure_ascii=False),dt.datetime.now(dt.timezone.utc).isoformat()))
    db.commit();return cur.rowcount==1

def execute_plan(driver,plan,db,report,delay=time.sleep):
    records=[]
    for index,p in enumerate(plan,1):
        vid=p['agendamentoIds']
        if not claim(db,p):continue
        # The intent is durable before sending; timeout or crash cannot silently resend it.
        try:r=driver.execute_async_script(SCRIPT,p)
        except Exception:r={'uncertain':True}
        if not isinstance(r,dict):r={'uncertain':True}
        label=outcome(r,vid);accepted=label.startswith('SOLICITAÇÃO ACEITA')
        status='ACEITA' if accepted else 'CONFERIR'
        db.execute('UPDATE attempts SET status=?,http=? WHERE id=? AND date=?',(status,r.get('http'),vid,p['novaData']));db.commit()
        record={'id':vid,'novaData':p['novaData'],'resultado':label,'http':r.get('http')};records.append(record)
        report.write(json.dumps(record,ensure_ascii=False)+'\n');report.flush();os.fsync(report.fileno())
        print(f'{index}/{len(plan)} · #{vid}: {label}')
        if not accepted:
            print('Lote interrompido. Os IDs restantes não foram enviados. Confira este ID no SISGR antes de nova tentativa.');break
        if index<len(plan):delay(3)
    return records

def load_panel_plan(path):
    path=Path(path)
    if path.stat().st_size>200000:raise ValueError('Arquivo de lote muito grande.')
    data=json.loads(path.read_text(encoding='utf-8-sig'))
    if not isinstance(data,dict) or data.get('format')!='ecosupply-reschedule-plan' or data.get('version')!=1:raise ValueError('Arquivo não reconhecido. Gere o lote pelo painel.')
    items=data.get('items')
    if not isinstance(items,list) or not 1<=len(items)<=100:raise ValueError('Escolha de 1 a 100 IDs.')
    ids=[];plan=[]
    for item in items:
        if not isinstance(item,dict) or item.get('status')!='ROTA':raise ValueError('O plano deve conter somente ROTA.')
        vid=item.get('id');source=item.get('sourceDate')
        if not isinstance(vid,str) or not isinstance(source,str):raise ValueError('ID/data de origem inválidos.')
        dt.date.fromisoformat(source)
        if source[:7]!=data.get('sourceMonth'):raise ValueError('Mês de origem inconsistente.')
        for key in ['newDate','turn','reason','left']:
            if not isinstance(data.get(key),str):raise ValueError('Campo inválido: '+key)
        plan.append(validate(vid,data['newDate'],data['turn'],data['reason'],data['left']));ids.append(vid)
    if len(set(ids))!=len(ids):raise ValueError('IDs duplicados no plano.')
    return data,plan

def main(plan_file=None):
    print('ECOSUPPLY — REAGENDAMENTO EM LOTE v2\nUma data, motivo e condição de saída comuns para toda a lista. Turno: qualquer turno.')
    if plan_file:
        source,plan=load_panel_plan(plan_file)
        ids=[p['agendamentoIds'] for p in plan];duplicates=0
        date=source['newDate'];reason=source['reason'];left=source['left']
        print('LOTE DO PAINEL · mês:',source['sourceMonth'],'· base atualizada em:',source.get('sourceUpdatedAt') or 'não informado')
        print('Datas de origem:',', '.join('#'+i['id']+' '+i['sourceDate'] for i in source['items']))
        print('A informação ROTA vem da base salva. Confira no SISGR se continua pendente antes de confirmar.')
    else:
        text=(ROOT/'ids.txt').read_text(encoding='utf-8-sig') if (ROOT/'ids.txt').exists() else ''
        if not any(line.strip() and not line.strip().startswith('#') for line in text.splitlines()):
            print('Cole os IDs abaixo (um por linha, vírgula ou espaço). Enter em uma linha vazia termina:')
            lines=[]
            while True:
                line=input()
                if not line.strip():break
                lines.append(line)
            text='\n'.join(lines)
        ids,duplicates=parse_ids(text)
        date=input('Nova data comum (dd/mm/aaaa): ').strip()
        reason=input('Motivo real comum: ').strip()
        left=input('O veículo saiu para coleta em TODOS os itens? (s/n): ').strip().lower()
        plan=[validate(vid,date,'qualquerturno',reason,left) for vid in ids]
    print('Se a condição de saída variar, divida a lista em lotes separados.')
    if left=='n':print('Checkbox desmarcado: omissão de caminhaoSaiu ainda precisa de validação real; comece com um único ID nessa condição.')
    lock=ROOT/'lote_em_execucao.lock'
    try:fd=os.open(lock,os.O_CREAT|os.O_EXCL|os.O_WRONLY,0o600)
    except FileExistsError:raise ValueError('Já existe um lote aberto ou interrompido. Feche o processo anterior antes de remover lote_em_execucao.lock e reabrir.')
    os.close(fd)
    db=None;driver=None
    try:
        db=open_ledger(ROOT/'historico.sqlite')
        skipped=[p for p in plan if db.execute('SELECT 1 FROM attempts WHERE id=? AND date=?',(p['agendamentoIds'],date)).fetchone()]
        plan=[p for p in plan if p not in skipped]
        print(f'IDs únicos: {len(ids)}. Duplicados retirados: {duplicates}. Tentativas anteriores ignoradas: {len(skipped)}.')
        if skipped:print('Não serão reenviados para a mesma data:',', '.join(p['agendamentoIds'] for p in skipped))
        if not plan:print('Nenhum item novo para enviar.');return
        print('IDS A ALTERAR:',', '.join(p['agendamentoIds'] for p in plan))
        print('DATA:',date,'| TURNO: qualquer turno | MOTIVO:',reason,'| VEÍCULO SAIU:',left)
        review=ROOT/'conferencia_lote.json'
        review.write_text(json.dumps(plan,ensure_ascii=False,indent=2),encoding='utf-8')
        print('Conferência salva:',review)
        from selenium import webdriver
        driver=webdriver.Chrome();driver.set_script_timeout(90);driver.get(ORIGIN)
        input('Faça login no Chrome e confira os IDs/status atuais no SISGR. Depois volte e pressione Enter. ')
        url=urlsplit(driver.current_url)
        if url.scheme!='https' or url.netloc!='ecosupply.sisgr.com':raise ValueError('Navegador fora do SISGR. Nada enviado.')
        phrase=f'ALTERAR LOTE {len(plan)}'
        if input(f'Para executar {len(plan)} itens para {date}, digite {phrase}: ').strip()!=phrase:
            print('Cancelado. Nada enviado.');return
        logs=ROOT/'resultados';logs.mkdir(exist_ok=True)
        path=logs/('lote_'+dt.datetime.now().strftime('%Y%m%d_%H%M%S_%f')+'.jsonl')
        with path.open('x',encoding='utf-8') as report:records=execute_plan(driver,plan,db,report)
        print('Relatório:',path)
        print('Aceitas:',sum(x['resultado'].startswith('SOLICITAÇÃO ACEITA') for x in records),'| Não enviados:',len(plan)-len(records))
        input('Confira as novas datas no SISGR. Enter fecha o Chrome. ')
    finally:
        if driver:
            try:driver.quit()
            except Exception:pass
        if db:db.close()
        lock.unlink(missing_ok=True)

if __name__=='__main__':
    try:main()
    except ValueError as e:print('Interrompido:',e)
    except KeyboardInterrupt:print('\nInterrompido. Consulte historico.sqlite e o SISGR antes de repetir um item já enviado.')
