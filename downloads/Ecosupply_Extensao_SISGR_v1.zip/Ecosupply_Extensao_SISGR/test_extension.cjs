const fs=require('fs'),vm=require('vm'),assert=require('assert'),crypto=require('crypto');
const {normalizePlan,payloadFor,resultState}=require('./core.js');
const plan=()=>({format:'ecosupply-reschedule-plan',version:1,sourceMonth:'2026-11',newDate:'24/11/2026',turn:'qualquerturno',left:'s',reason:'Revisão autorizada',items:[{id:'123',sourceDate:'2026-11-03',status:'ROTA'},{id:'124',sourceDate:'2026-11-04',status:'ROTA'}]});
assert.equal(normalizePlan(plan()).items.length,2);
for(const edit of [p=>p.items.push(p.items[0]),p=>p.items[0].status='EFETIVADO',p=>p.newDate='31/02/2026',p=>p.items[0].sourceDate='2026-10-01',p=>p.items[0].id='1,2']){const p=plan();edit(p);assert.throws(()=>normalizePlan(p))}
assert.equal(payloadFor(normalizePlan(plan()),'123').caminhaoSaiu,'1');const n=plan();n.left='n';assert(!('caminhaoSaiu' in payloadFor(normalizePlan(n),'123')));
assert.equal(resultState({http:200,accepted:true,id:'other'},'123'),'conferir');
let data={},posts=0,opened=[],injectedPayload;const id='testextension';
const chrome={runtime:{id,getURL:p=>'chrome-extension://'+id+'/'+p,onMessage:{addListener(){}},onInstalled:{addListener(){}}},storage:{local:{async get(key){return {[key]:structuredClone(data[key])}},async set(x){Object.assign(data,structuredClone(x))},async remove(key){delete data[key]},async setAccessLevel(){}}},tabs:{async create(x){opened.push(x)},async query(){return [{id:2,active:true,url:'https://ecosupply.sisgr.com/agendamentos/localizar'}]},async get(){return {id:2,url:'https://ecosupply.sisgr.com/agendamentos/localizar'}}},scripting:{async executeScript(x){posts++;injectedPayload=x.args[0];return [{result:{http:200,accepted:true,id:x.args[0].agendamentoIds}}]}},action:{onClicked:{addListener(){}}}};
const c={chrome,console,crypto,URL,setTimeout,clearTimeout,structuredClone,Date};vm.createContext(c);c.importScripts=name=>vm.runInContext(fs.readFileSync(__dirname+'/'+name,'utf8'),c);vm.runInContext(fs.readFileSync(__dirname+'/background.js','utf8'),c);
const panel={id,frameId:0,url:'https://ecosupply-logistica-api.onrender.com/',tab:{id:1}};
const review={id,frameId:0,url:'chrome-extension://'+id+'/review.html',tab:{id:3}};
async function call(m,s=panel){c.m=m;c.s=s;return vm.runInContext('handle(m,s)',c)}
(async()=>{
 await assert.rejects(call({command:'prepare',plan:plan()},{...panel,url:'https://evil.invalid/'}));
 const {jobId}=await call({command:'prepare',plan:plan()});assert.equal(posts,0);assert.equal(opened.length,1);
 await assert.rejects(call({command:'next',jobId}));assert.equal(posts,0);
 await assert.rejects(call({command:'confirm',jobId},{...review,url:'file:///review.html'}));
 await call({command:'confirm',jobId},review);let result=await call({command:'next',jobId},review);assert.equal(posts,1);assert.equal(result.job.items[0].state,'aceita');assert.equal(injectedPayload.agendamentoIds,'123');
 await call({command:'next',jobId},review);assert.equal(posts,1); // spacing enforced in worker
 data['job:'+jobId].nextAt=0;
 chrome.scripting.executeScript=async()=>{posts++;throw Error('timeout')};result=await call({command:'next',jobId},review);assert.equal(result.job.state,'conferir');assert.equal(result.job.items[1].state,'conferir');
 await call({command:'next',jobId},review);assert.equal(posts,2);
 const second=await call({command:'prepare',plan:plan()});await call({command:'confirm',jobId:second.jobId},review);result=await call({command:'next',jobId:second.jobId},review);assert.equal(result.job.items[0].state,'ignorado');assert.equal(posts,2);
 // Recover an interrupted intent without dispatching again.
 data['job:'+second.jobId].items[1].state='enviando';result=await call({command:'review',jobId:second.jobId},review);assert.equal(result.job.state,'conferir');assert.equal(posts,2);
 await assert.rejects(call({command:'status',jobId},{...panel,tab:{id:99}}));
 // Verify injected transport is fixed, same-origin, and does not leak the raw response.
 c.location={origin:'https://ecosupply.sisgr.com',pathname:'/agendamentos/localizar'};c.document={querySelector:()=>null};c.AbortController=AbortController;c.URLSearchParams=URLSearchParams;let sent;
 c.fetch=async(url,options)=>{sent={url,options};return {status:200,ok:true,json:async()=>({erro:false,agendamentos:{'123':{erro:false}},private:'DO_NOT_RETURN'})}};
 c.payload=payloadFor(normalizePlan(plan()),'123');let raw=await vm.runInContext('sendInSisgr(payload)',c);
 assert.equal(raw.accepted,true);assert(!JSON.stringify(raw).includes('DO_NOT_RETURN'));assert.equal(sent.url,'/agendamentos/reagendar');assert.equal(sent.options.credentials,'same-origin');assert.equal(sent.options.redirect,'error');
 c.document.querySelector=()=>({});raw=await vm.runInContext('sendInSisgr(payload)',c);assert.equal(raw.http,401);
 console.log('Extensão: plano, origem, confirmação, intervalo, falha, histórico e recuperação validados sem acessar SISGR.');
})().catch(e=>{console.error(e);process.exitCode=1});
