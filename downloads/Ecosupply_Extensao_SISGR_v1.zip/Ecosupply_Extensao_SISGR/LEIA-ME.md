# Ecosupply — extensão SISGR v1

## Instalar uma vez no Chrome ou Edge
1. Extraia este ZIP em uma pasta fixa. Não apague nem mova a pasta depois de instalar.
2. No Chrome, abra chrome://extensions. No Edge, edge://extensions.
3. Ative Modo do desenvolvedor.
4. Clique Carregar sem compactação e selecione a pasta que contém manifest.json.
5. Abra/recarregue o painel: https://ecosupply-logistica-api.onrender.com/.
6. No mesmo perfil do navegador, abra https://ecosupply.sisgr.com/ e faça login normalmente.

Esta versão é para Chrome/Edge. Não é pacote instalável do Firefox. Se estiver usando Firefox para o painel, abra painel e SISGR no Chrome/Edge com a extensão instalada. Não precisa Python.

## Reagendar
1. No painel v1.13, vá a Reagendamento em lote. Clique Conectar extensão se necessário.
2. Escolha mês, cidade, motorista, datas e os IDs ROTA desejados (até 100).
3. Informe nova data, motivo e saída do veículo. Confira o resumo completo e marque a confirmação.
4. Clique Enviar para conferência na extensão. Uma aba própria da extensão abre com os dados.
5. Confira no SISGR se os IDs continuam pendentes e marque a conferência da extensão. Clique Confirmar envio no SISGR.
6. Mantenha essa aba aberta. O lote envia um ID por vez, aguardando pelo menos 3 segundos entre solicitações.
7. Acompanhe resultados na extensão e no painel. Use Baixar relatório para conservar os resultados.
8. Confira as novas datas no SISGR. Sincronize origem e destino no painel para atualizar a base com a API. A extensão não altera o banco do painel pelo simples aceite.

## Sessão e permissões
Apenas o endereço padrão do painel acima e o domínio SISGR da Ecosupply estão integrados. Domínio próprio exige ajustar manifest.json, bridge.js e core.js e reinstalar/recarregar a extensão. Não amplie para todos os sites. A extensão pede scripting, storage e permissão para atuar no SISGR; não pede permissão de ler cookies. Ela usa a sessão da aba e não transfere senha/cookie ao Render. Não há token da API nem credenciais no código.

Use somente uma aba SISGR logada por perfil para evitar ambiguidade; o lote fixa a aba escolhida no início. Se sessão expirar, retornar login/HTML, ocorrer erro HTTP, timeout de 20 segundos ou resposta sem confirmação por ID, o lote para. Não tenta contornar autenticação nem repetir uma solicitação. Timeout pode ocorrer após gravação no servidor: confira o cadastro antes de qualquer nova tentativa.

O status ROTA e a data de origem vêm da base salva, não de uma consulta ao vivo antes do POST. A conferência local é obrigatória. A rota POST /agendamentos/reagendar e os campos foram observados nos testes locais anteriores; ainda é necessário um teste real desta extensão com poucos IDs. Não é uma integração oficialmente documentada da API pública SISGR.

## Histórico e interrupções
Intenção de cada ID/data é gravada no armazenamento da extensão ANTES do envio. O mesmo ID para a mesma data não é reenviado automaticamente nesse perfil, mesmo se o motivo mudar. Os registros locais não importam historico.sqlite do executor Python; não selecione de novo itens já concluídos com o executor para a mesma data.

Se fechar a aba da extensão, use seu ícone na barra de extensões para reabrir o último lote. Um envio com resultado desconhecido bloqueia o lote para conferência. Não limpe o armazenamento, reinstale ou troque de perfil para forçar reenvio. Cancelar/interromper não desfaz envios já aceitos; se clicar durante um envio, ele pode terminar antes da interrupção.

Histórico e resultados ficam neste perfil e não são compartilhados entre computadores. Não rode o mesmo lote em máquinas/perfis diferentes. Sessão fechada ou suspensão do computador interrompe o fluxo; a extensão não é um agendador em nuvem.

A seleção de pendentes e o botão Enviar ficam no painel, mas o Chrome exige a confirmação e execução pela extensão instalada. Se já houver um lote em revisão/execução, finalize/cancele esse antes de preparar outro. O antigo executor local por arquivo continua como alternativa.

## Validação
Testes simulados: node test_extension.cjs. Incluem rejeição de origem indevida, bloqueio de envio pelo painel sem revisão, validação de plano, ID repetido, datas inválidas, pausa, interrupção, histórico, recuperação de intenção incompleta e transporte de formulário na rota fixa. Não houve acesso autenticado nem alteração no SISGR pelo assistente durante a construção desta versão.
